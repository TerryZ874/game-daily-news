---
name: game-design-workshop
description: "Knowledge base from \"游戏设计梦工厂 (Game Design Workshop, 4th Edition)\" by Tracy Fullerton. Use for applying Fullerton's Playcentric Design frameworks, thinking with her game design mental models, or referencing specific chapters on formal/dramatic elements, prototyping, playtesting, and the game industry."
---

<!-- argument-hint: [topic, framework name, or chapter number] -->

# 游戏设计梦工厂 (Game Design Workshop) — 第4版
**Author**: Tracy Fullerton (特雷西·弗雷顿) | **Pages**: ~586 | **Chapters**: 16 | **Generated**: 2026-06-15

## How to Use This Skill

- **Without arguments** — load Core Frameworks below for reference
- **With a topic** — ask about `playtesting`, `flow`, `formal elements`, `prototyping`; I find and read the relevant chapter
- **With chapter** — ask for `ch05`; I load that specific chapter
- **Browse** — ask "what chapters do you have?" to see the full index

When you ask about a topic not covered in Core Frameworks below, I will read the relevant chapter file before answering.

---

## Core Frameworks & Mental Models

### 以游玩体验为中心的设计 (Playcentric Design)
Tracy Fullerton 的核心方法论：游戏设计师不是掌控一切细节的独裁者，而是创造有潜力的体验，邀请玩家来展开互动。**"设计游戏就像主办派对"** — 把食物、音乐、氛围准备好，然后看客人如何互动。核心循环：设计 → 原型 → 游戏测试 → 观察玩家 → 修改 → 重复。

### 游戏的八大形式元素 (Formal Elements)
所有游戏共享的深层结构语法 — 用这个框架分析任何游戏：
- **玩家（Players）**: 自愿参与、主动选择的人 — 数量、角色、交互模式（7种）决定体验
- **目标（Objectives）**: 玩家要达成的明确目标 — 没有它，游戏结构松散
- **规程（Procedures）**: 规则允许的"玩的方式" — 引导玩家行为
- **规则（Rules）**: 定义物品/概念，限制行为 — 权力来自玩家自愿接受
- **资源（Resources）**: 稀缺+有用的物品 — 价值=稀缺性×对目标的帮助
- **冲突（Conflict）**: 规程和规则阻止玩家直接达成目标 — 张力来源
- **边界（Boundaries）**: 魔法圈 — 与日常生活分隔的游戏空间
- **产出（Outcomes）**: 胜负/分数 — 给玩家完成感

### 心流理论 (Flow Theory — Csikszentmihalyi)
当挑战与技能匹配时，玩家进入心流状态。八个条件：
1. 需要技能的有挑战性的活动
2. 行动与意识的融合（全神贯注）
3. 清晰的目标和反馈
4. 专注于当前任务
5. **控制的悖论** — 结果不确定但可被影响=真正的掌控感
6. 失去自我意识
7. 时间的扭曲
8. 体验过程本身即是目的（autotelic）

**心流公式**: 技能≈挑战→心流 | 技能<挑战→焦虑 | 技能>挑战→无聊

### 原型方法论
**永远先做实物原型（纸面原型）再写代码。** 纸面上的迭代不需要代价 — 不喜欢结构？立刻改，马上再试。代码会让改变变得困难。软件原型分四种：玩法原型（验证机制）、美学原型（测试视觉）、动觉原型（测试手感）、技术原型（验证可行性）。原则："去偷、去仿造、去改造" — 原型不是工程，不是真正的代码。

### 游戏测试是核心
游戏测试从项目第一天开始，不是开发末期的可有可无。测试者是你的向导 — 让你重新客观地看到游戏。**观察 > 倾听** — 玩家做什么比他们说什么更真实。沉默 = 困惑（不是沉浸）。永远不为自己辩护 — 为什么导致困惑才是要解决的问题。

### 创意方法论
创意不是等来的。Csikszentmihalyi 的五阶段（准备→酝酿→洞见→评估→精化）是非线性的。头脑风暴七原则：陈述挑战、拒绝评论、变换方法、制造轻松环境、写在墙上、数量多多益善、60分钟上限。桌面游戏是设计师的训练场 — 规则不藏在代码里，更容易解构学习。

### 系统的四元素
对象（Object）、属性（Property）、行为（Behavior）、关系（Relationship） — 这四个元素互相作用产生系统动态。属性越多=难预测；关系可以固定、动态或随机。移除或改变任何元素系统行为都会变化 — 如果不变，那就只是一堆元素的集合。

### Callois 的四种玩的类型
- **竞争类（Agon）**: 策略、对战、体育运动
- **机会类（Alea）**: 赌博、随机性
- **代入类（Mimicry）**: 角色扮演、幻想
- **眩晕类（Ilinx）**: 过山车、极限运动
每种跨越"自由形式玩法↔规则基础玩法"的谱系 — 组合不同类型来定义核心乐趣。

### "Yes! and..." — 团队创意核心原则
在团队讨论/头脑风暴中，接住对方的想法并在此基础上构建。不是说"No, but..."而是"Yes, and..."。源自即兴表演 — 适用于所有创意协作场景。

---

## Chapter Index

| # | Title | Key Frameworks |
|---|-------|----------------|
| [ch01](chapters/ch01-game-designer-role.md) | 游戏设计师的角色 | Playcentric Design, 设计师作为玩家拥护者, 迭代式设计 |
| [ch02](chapters/ch02-structure-of-games.md) | 游戏的结构 | 八大形式元素, Lusory Attitude, 魔法圈 |
| [ch03](chapters/ch03-working-with-formal-elements.md) | 形式元素的运用 | 7种玩家交互模式, Bartle 玩家类型, 程序性修辞 |
| [ch04](chapters/ch04-working-with-dramatic-elements.md) | 戏剧元素的运用 | 心流理论, Callois 4种玩, 10种玩家乐趣类型 |
| [ch05](chapters/ch05-working-with-system-dynamics.md) | 运用系统动态 | 系统四元素, 经济系统, 涌现式系统, 反馈循环 |
| [ch06](chapters/ch06-conceptualization.md) | 概念构想 | 创意五阶段, 头脑风暴七原则, 游戏解构 |
| [ch07](chapters/ch07-prototyping.md) | 原型 | 实物原型方法论, 纸面原型, 战舰/逆流而上案例 |
| [ch08](chapters/ch08-software-prototyping.md) | 软件原型 | 四种软件原型, Mikros 四问, 动觉原型 |
| [ch09](chapters/ch09-playtesting.md) | 游戏测试 | 测试四阶段, 观察vs倾听, 迭代循环 |
| [ch10](chapters/ch10-functionality-completeness-balance.md) | 功能性、完备性和平衡性 | 三问题诊断, 非对称平衡, 变量调整 |
| [ch11](chapters/ch11-fun-and-accessibility.md) | 乐趣和易用性 | 乐趣六维度, 易用性设计, 学习曲线 |
| [ch12](chapters/ch12-team-structure.md) | 团队结构 | 团队角色, Yes!and!, 敏捷vs瀑布 |
| [ch13](chapters/ch13-stages-of-development.md) | 开发的阶段和方法 | 五阶段模型, 垂直切片, 范围蔓延 |
| [ch14](chapters/ch14-communicating-your-design.md) | 沟通你的设计 | 沟通工具谱系, 电梯游说, GDD写作 |
| [ch15](chapters/ch15-understanding-the-game-industry.md) | 理解新的游戏产业 | 三层级, 商业模式, 数字分发 |
| [ch16](chapters/ch16-entering-the-industry.md) | 如何进入游戏产业 | 入行三路径, 作品集原则, Game Jam |

## Topic Index

- **autotelic** → ch04
- **Bartle 玩家类型** → ch03
- **Callois 玩的类型** → ch04
- **Elevator Pitch（电梯游说）** → ch14
- **Flow（心流）** → ch04
- **Formal Elements（形式元素）** → ch02, ch03
- **Game Jam** → ch16
- **GDD（设计文档）** → ch14
- **Lusory Attitude（游戏态度）** → ch02
- **Magic Circle（魔法圈）** → ch03
- **Playcentric Design** → ch01, ch09
- **Procedural Rhetoric（程序性修辞）** → ch03
- **Prototype（原型）** → ch07, ch08
- **Scope Creep（范围蔓延）** → ch13
- **Vertical Slice（垂直切片）** → ch13
- **Yes! and...** → ch06, ch12
- **创意 / 头脑风暴** → ch06
- **非对称对抗** → ch03
- **交互模式（7种）** → ch03
- **经济的类型** → ch05
- **平衡性** → ch10
- **设计师角色** → ch01
- **玩家类型（10种乐趣）** → ch04
- **协作游戏** → ch03
- **涌现式系统** → ch05
- **游戏测试** → ch09
- **纸面原型** → ch07
- **作品集** → ch16

## Supporting Files

- [glossary.md](glossary.md) — 29 key terms with definitions
- [patterns.md](patterns.md) — 10 design patterns and techniques
- [cheatsheet.md](cheatsheet.md) — quick reference decision rules and checklist

---

## Scope & Limits

This skill covers the book content of Game Design Workshop (4th Edition) by Tracy Fullerton. The OCR text comes from the Chinese edition (游戏设计梦工厂 第4版). For hands-on implementation in your specific engine (Unity/Godot/Unreal), combine with project-specific tools. For topics beyond this book, check related skills or ask the agent directly.
