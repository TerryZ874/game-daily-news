# Skill Benchmark: mini-game-design

**Model**: <model-name>
**Date**: 2026-06-04T04:34:55Z
**Evals**:  (3 runs each per configuration)

## Summary

| Metric | Config A | Config B | Delta |
|--------|------------|---------------|-------|
| Pass Rate | 0% ± 0% | 0% ± 0% | +0.00 |
| Time | 0.0s ± 0.0s | 0.0s ± 0.0s | +0.0s |
| Tokens | 0 ± 0 | 0 ± 0 | +0 |