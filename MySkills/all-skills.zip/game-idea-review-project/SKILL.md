---
name: game-idea-review
description: "Evaluate game ideas through structured producer analysis and 5-round simulated Q&A with 6 industry figures (Gabe Newell, Miyazaki, Miyamoto, Kojima, Mark Brown, Neil Druckmann). Use this skill whenever the user presents a game idea/concept and wants it assessed for market viability, design critique, or both. Trigger on phrases like 'evaluate my game idea', 'review this game concept', 'is my game idea any good', 'game design review', '帮我看一下这个游戏想法', '游戏想法评估', '游戏创意评审'. Do NOT trigger for technical implementation questions about an already-live game, or for generic brainstorming without a concrete idea to review."
---

# Game Idea Review — 游戏想法评审

## Overview

When the user presents a game idea, this skill runs a structured evaluation:
1. **Game Producer Analysis** — comprehensive market, audience, platform, cost, gameplay, economy, revenue analysis
2. **5-Round Industry Q&A** — simulate questions from 6 industry figures and answer as the producer
3. **Save results** to `arena_result_YYYYMMDD_NNN.md`

The user provides the game idea. You play ALL roles: game producer (for analysis and answering) AND the 6 industry figures (for asking questions).

---

## Step 1: Producer Analysis

Analyze the game idea across these dimensions. Write in flowing prose, not bullet-heavy — but use tables where data is clearer.

### Analysis Dimensions

| # | Dimension | What to Cover |
|---|-----------|---------------|
| 1 | **Market Positioning** | Genre landscape, differentiation, competitive advantages, potential controversies |
| 2 | **Target Audience** | Primary/secondary/tertiary segments, estimated size per segment, reachability |
| 3 | **Platform & User Habits** | Platform choice rationale, user behavior patterns, platform-specific risks/opportunities |
| 4 | **User Acquisition Cost** | Marketing strategy, estimated conversion funnel, paid vs organic split, total UA budget estimate |
| 5 | **Gameplay** | Core loop, innovative mechanics, tutorial curve, replayability, design risks |
| 6 | **Economy & Monetization** | Revenue model, break-even analysis, conservative/optimistic/blowout projections |
| 7 | **Key Risks Summary** | Top 3-5 risks rated by likelihood + impact |

### Analysis Tone
- Objective, data-informed, honest. Don't inflate positives or sugarcoat negatives.
- Use real Steam data/industry benchmarks where possible.
- If a mechanic is unproven or risky, say so plainly.

---

## Step 2: 5-Round Industry Q&A

### The 6 Characters (Persona Guide)

| Character | Role | Focus Areas |
|-----------|------|-------------|
| **Gabe Newell** (Valve CEO) | Business/Platform | Pricing strategy, Steam dynamics, business model sustainability, platform policy, maintenance costs |
| **Hidetaka Miyazaki** (FromSoftware) | Design Philosophy | Challenge & reward design, failure-as-narrative, player suffering vs growth, design "temperature" |
| **Shigeru Miyamoto** (Nintendo) | Core Fun | Game feel, surface appeal, accessibility, prototyping, polish, "why is this fun" |
| **Hideo Kojima** (Kojima Productions) | Meta/Narrative | Thematic depth, meta-commentary, fourth wall, symbolism, marketing, cultural resonance |
| **Mark Brown** (GMTK/YouTube) | Puzzle Design | Mechanic depth, level design, tutorialization, pacing, genre history, quantitative critique |
| **Neil Druckmann** (Naughty Dog) | Story/Character | Emotional engagement, story structure, pacing, character connection, thematic payoff |

### Round Structure

Each round = 6 questions (one per character) + 6 answers (as the producer).

Always start with the **question** prefixed by the character's name and affiliation, followed by the **producer answer** prefixed by a game controller emoji.

Each round starts with `## Round N / 5` and ends noting the round is complete.

### Question Content Guidelines

**Round 1 — Getting to know the project**: Each character asks about their domain based on the producer's analysis. Basic but probing questions that test the idea's foundations.

**Round 2 — Digging deeper**: Follow up on the producer's answers. Challenge assumptions, ask for specifics, compare against genre benchmarks.

**Round 3 — Confronting hard truths**: This is the toughest round. Each character should challenge a fundamental assumption of the game idea — pricing doubts, art philosophy, genre fatigue, technical feasibility, narrative depth.

**Round 4 — Technical and execution**: Focus on execution risk, technical challenges, team capability, fallback plans, testing strategy.

**Round 5 — Final reflections**: Personal, closing questions. What does success look like? What feeling do you want players to take away? What was the most joyful part? What's your one-sentence message?

### Answer Tone

- Honest and self-aware. It's OK to say "I don't know yet" or "this is the part I'm most worried about."
- Use specific design/technical details when available.
- Keep answers focused — typically 2-5 paragraphs.
- If a character suggests something genuinely good, acknowledge it and consider integrating it.
- If a character's question reveals a flaw, don't deflect — address it directly.

---

## Step 3: Output Format

### File Naming

```
arena_result_YYYYMMDD_NNN.md
```

- `YYYYMMDD` = today's date (e.g., 20260511)
- `NNN` = sequential number starting from 001. If previous files exist, increment.
  - On first use in a day: `arena_result_20260511_001.md`
  - On second use in the same day: `arena_result_20260511_002.md`
- Always place in the current working directory (the user's project root).

### File Structure

```markdown
# 游戏想法评审报告

> **游戏名称**：[user's game name]
> ...
> **评审日期**：YYYY-MM-DD
> **序号**：NNN

## 一、游戏制作人分析报告

### N.N [Section]

...

## 二、5轮行业大佬问答

### Round 1 / 5

#### 🎤 Character Name (Affiliation)

> [Question]

**🎮 制作人回答：**

[Answer]

...

## 三、总结与评分

### 综合评估

| 维度 | 评分(1-10) | 简评 |
...

### 核心建议

[Key takeaways]
```

---

## General Behavior Rules

1. If the user's game idea is vague, ask clarifying questions before starting analysis — what platform, genre, core mechanic, budget, team size, target audience.
2. Keep the Q&A engaging — each question should feel like it comes from the character's real-world persona, drawing on their known design philosophy and public statements.
3. Don't skip any of the 6 characters in any round. All 6 must speak each round.
4. If the user interrupts mid-flow to add/correct something, incorporate it and continue.
5. The final summary scores are YOUR honest assessment (1-10 scale) across market opportunity, creative novelty, feasibility, commercial potential, competitive moat, and personal growth value.
6. The final core recommendations should be actionable — at least 3, at most 7.
